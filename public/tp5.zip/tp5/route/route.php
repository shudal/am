<?php
Route::rule("/login","index/login/index");
Route::rule("/read","index/login/read");
return [

];
