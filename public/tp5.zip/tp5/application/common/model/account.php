<?php

namespace app\common\model;

use think\Model;

class account extends Model
{
    //
}
